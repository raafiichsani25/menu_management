<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
  <title><?= $title; ?></title>

</head><body>

 <table width="100%">
<tr>
 <td width="25" align="center"><img src="<?= base_url('assets/img/pdf/radika.jpg'); ?>" width="100%" height="13%" style="border-radius: 50%;"></td>
<td width="50" align="center"><h1>Laporan Data Transaksi <br>RETAIL RADIKA</h1><h4>Dusun Krajan Rt.014 Rw.004 Desa Sukasari Kecamatan Sukasari Kabupaten Subang - Jawa Barat</h4></td>

</tr>
</table>
<hr>
      <h4>Nama Pembeli : <?= $pembeli['pembeli']; ?></h4>
     <h4>Total Transaksi : <?= $total_rows; ?></h4>
     <table border="3" cellspacing="3" cellpadding="3">
                              <thead>
                                <tr>
                                  <th scope="col">No</th>
                                  <th scope="col">Barang</th>
                                  <th scope="col">Harga Jual</th>
                                  <th scope="col">Qty</th>
                                  <th scope="col">Jumlah</th>
                                 
                    
                                </tr>
                              </thead>
                              <tbody>
                                
                                <?php $i = 1; ?>
                                <?php $total = 0; ?>
                                <?php foreach($transaksi as $tr): ?>
                                <tr>
                                  <th scope="row"><?= $i; ?></th>
                                  <td align="center"><?= $tr['nama_barang']; ?></td>

                                   <td align="center"><?= $tr['harga_jual']; ?></td>


                                  <td align="center"><?= $tr['qty']; ?></td>

                                 <td>

                                    <?php $jumlah = $tr['harga_jual'] * $tr['qty'];?>

                                   
                                    <?= number_format($jumlah,0,',','.'); ?>

                                   </td>                           
                      
                                </tr>
                                 <?php $total += $jumlah; ?>
                                    <?php $i++; ?>                       
                                <?php endforeach; ?>   

                                </tbody>
                            </table>

                              <h1 class="text-primary">Total = Rp.<?= number_format($total,0,',','.'); ?></h1>

                           
</body>
</html>